// Example: Scroll to top on reload
window.onload = function () {
  window.scrollTo(0, 0);
};